package aman.lyricify;

public class LyricWord {
    public long time;
    public String text;

    public LyricWord(long time, String text) {
        this.time = time;
        this.text = text;
    }
}
